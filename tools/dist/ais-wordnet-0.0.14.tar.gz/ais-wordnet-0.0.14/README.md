docs:
    https://github.com/minhdc/ais-wordnet






